package recfun
import common._

object Main {

  def balance(chars: String) = {
    def balanceIter(chars: List[Char], count: Int): Boolean={
      if (count < 0) 
      {
        false
      }
      else if (chars.isEmpty) 
      {
        count == 0
      }
      else if (chars.head == '(') 
      {
        balanceIter(chars.tail, count + 1)
      }
      else if (chars.head == ')') 
      {
        balanceIter(chars.tail, count - 1)
      }
      else 
      {
        balanceIter(chars.tail, count)
      }
    }
    balanceIter(chars.toList,0)
  }

  def countChange(money: Int, coins: List[Int]): Int = {

  def  countChangeAux(moneyLeft: Int, coinsLeft: List[Int]): Int = {

    
     if (money == 0) 1
     else if (money < 0 || coins.isEmpty) 0
     else countChange(money - coins.head, coins) + countChange(money, coins.tail)
     
  }

  countChangeAux(money, coins)
}
}
